﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Windows.Forms;
using System.Security.Permissions;
using System.Runtime.ExceptionServices;
using System.CodeDom;

namespace MyPersonClass1
{
    public class Person
    {
        public string Age(int year, int month)
        {
            int age = DateTime.Now.Year - year;

            if (DateTime.Now.Month < month)
            {
                age -= 1;
            }

            if (age < 9 & age > 0)
            {
                MessageBox.Show("Тебе " + age + "? Нормальный!");
            }

            if (age < 0)
            {
                MessageBox.Show("Тебе " + age + "? НОРМ!");
            }
            return Convert.ToString(age);
        }

        public void Output(string name, string surname, string age)
        {
            if (name == "" || surname == "" || name == "Имя" || surname == "Фамилия")
            {
                MessageBox.Show("Введите свои данные");
            }
            else
            {
                MessageBox.Show("Имя: " + name + "\n" + "Фамилия: " + surname + "\n" + "Возраст: " + age);
            }
        }

    }
}
