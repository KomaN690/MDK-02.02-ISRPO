﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5ygol
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            System.Drawing.Drawing2D.GraphicsPath gp = new
      System.Drawing.Drawing2D.GraphicsPath();

            // 2. Создать массив точек, соответствующих координатам
            //    пятиугольника, образовывающего форму.
            // 2.1. Объявить экземпляр типа "массив точек Point[]".
            //    Point - это класс, который описывает точку на экране.
            Point[] mp = new Point[5];

            // 2.2. Выделить память для каждой точки и заполнить
            //         ее значениями.
            mp[0] = new Point(0, 150);
            mp[1] = new Point(50, 300);
            mp[2] = new Point(420, 300);
            mp[3] = new Point(650, 150);
            mp[4] = new Point(400, 0);

            // 3. Добавить массив точек Point[] в экземпляр gp
            gp.AddPolygon(mp);

            // 4. Создать область (Region) на основе последователь-ности точек gp
            Region rg = new Region(gp);

            // 5. Установить область формы this.Region
            //       в новое значение rg
            this.Region = rg;

        }
    }
}
